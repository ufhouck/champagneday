// OpenWeatherMap API key
export const WEATHER_API_KEY = '72fc1f39f6ee44de8a874625241911';